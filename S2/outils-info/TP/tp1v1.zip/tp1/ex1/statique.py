p = 5
q = 3 * p

somme = p + q

res="p vaut {} et q vaut {}, leur somme vaut {}"
print(res.format(p, q, somme))